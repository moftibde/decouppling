# __init__.py 
from decouppling import Decouppling
# verstion of the decouple package 
__version__ = "1.0.0"
